<?php

$name = $_POST["name"];

echo "hello $name";

 ?>
