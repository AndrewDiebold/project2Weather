<?php


  $students = array();

  $students[] = array("id"=>1, "name"=>"joe blow");
  $students[] = array("id"=>12, "name"=>"aaron Rodgers");
  $students[] = array("id"=>42, "name"=>"tom test");

  echo json_encode($students);


 ?>
