const init = () => {

  document.querySelector("#plainText").addEventListener("click", plainTextRequest);
  document.querySelector("#xml").addEventListener("click", xmlRequest);
  document.querySelector("#json").addEventListener("click", jsonRequest);

}

//generic xhr request method
const xhrRequest = (url, verb, responseType, callback, parameters) => {

  let xhr = new XMLHttpRequest();
  let params = ""
  for (var key in parameters) {
      var value = parameters[key];
      params += `${key}=${value}&`;
  }
  params = params.substring(0, params.length - 1);

  if(verb == "get") {
    url += "?" + params;
  }

  xhr.open(verb, url);


  //callback
  xhr.onreadystatechange = () => {
    if (xhr.readyState == 4) {
      if(responseType == "text") {
        callback(xhr.responseText);
      } else if(responseType == "json") {
        callback(JSON.parse(xhr.responseText));
      } else if(responseType == "xml") {
        if(xhr.responseXML) {
          callback(xhr.responseXML);
        } else {
          let parser = new DOMParser().parseFromString(xhr.responseText, "application/xml");
          callback(parser);
        }
      }
    }
  }

  if(verb == "post") {
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send(params)
  } else {
    xhr.send(null);
  }
}

const jsonRequest = () => {
  xhrRequest("json.php", "get", "json", students => console.log(students[2].name));
}

const xmlRequest = () => {
  xhrRequest("xml.php", "get", "xml", students => console.log(students.getElementsByTagName("student").length));
}

const plainTextRequest = () => {
  let params = [];
  params["name"] = "Bryan";
  params["student_id"] = 10;
  xhrRequest("plainText.php", "post", "text", data => console.log(data), params);
}


window.onload = init;
