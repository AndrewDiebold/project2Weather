<?php

  header("Content-Type: application/xml");

  $contents = file_get_contents("./students.xml");

  echo $contents;

?>
